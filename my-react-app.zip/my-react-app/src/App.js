import React, { useEffect, useState } from "react";
import "./App.css";
import AddUser from "./components/AddUser";
import SearchComponent from './components/SearchComponent';
import Lottie from 'react-lottie';
import data from "./logo_animation.json";


const App = () => {
  const [users, setUsers] = useState([]);
  useEffect(() => {
    fetchData();
  }, []);

  const defaultOptions = {
    loop: true,
    autoplay: true,
    animationData: data,
    rendererSettings: {
      preserveAspectRatio: 'xMidYMid slice'
    }
  };

  const fetchData = async () => {
    await fetch("https://jsonplaceholder.typicode.com/users")
      .then((res) => res.json())
      .then((data) => setUsers(data))
      .catch((err) => {
        console.log(err);
      });
  };



  const onAdd = async (name, phone) => {
    await fetch("https://jsonplaceholder.typicode.com/users", {
      method: "POST",
      body: JSON.stringify({
        name: name,
        phone: phone,
      }),
      headers: {
        "Content-type": "application/json; charset=UTF-8",
      },
    })
      .then((res) => {
        if (res.status !== 201) {
          return;
        } else {
          return res.json();
        }
      })
      .then((data) => {
        setUsers((users) => [...users, data]);
      })
      .catch((err) => {
        console.log(err);
      });
  };

  const onDelete = async (id) => {
    await fetch(`https://jsonplaceholder.typicode.com/users/${id}`, {
      method: "DELETE",
    })
      .then((res) => {
        if (res.status !== 200) {
          return;
        } else {
          setUsers(
            users.filter((user) => {
              return user.id !== id;
            })
          );
        }
      })
      .catch((err) => {
        console.log(err);
      });
  };

  
const inputStyles = {
  padding: '10px',
  borderRadius: '8px',
  marginLeft:'5px',
  marginRight:'10px',
  backgroundColor: '#ffffff',
  border: '2px solid #ccc',
  fontSize: '16px',
  width: '20%',
  boxSizing: 'border-box',
  outline: 'none',
};
const pStyle = {
  margin:"10px",
}
  return (
    <div className="App">
      <br/>
     <Lottie options={defaultOptions}
        height={400}
        width={400}
      />
     <h1>Contact Tracer</h1>
      <p style={pStyle}>No Need to worry about your contacts. We will handle it.</p>
      <br></br>
      <hr></hr>
      <AddUser onAdd={onAdd} />
  <SearchComponent data={users} onDelete={onDelete} />
      <br />
    </div>
  );
};

export default App;
