import React, { useState } from "react";
import Button from '@material-ui/core/Button';

const AddUser = ({ onAdd }) => {

  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');

  const handleOnSubmit = (e) => {
    e.preventDefault();
    onAdd(name, phone);
    setName('');
    setPhone('');
  };

  const inputStyles = {
    padding: '10px',
    borderRadius: '8px',
    backgroundColor: '#ffffff',
    border: '2px solid #ccc',
    fontSize: '16px',
    width: '30%',
    marginTop: '10px',
    marginBottom: '10px',
    boxSizing: 'border-box',
    outline: 'none',
    alignItems: 'center',
    justifyContent: 'center',
    marginLeft: '10px', // Add this property to center the input horizontally
    marginRight: '10px', // Add this property to center the input horizontally
  };
  const h3Style = {
    marginTop: '60px'
  };
  const pStyle = {
    margin:"10px",
  }
  return (
    <div >
      <form onSubmit={handleOnSubmit}>
        <h3 style={h3Style}>New Contact</h3>
        <p style={pStyle}>
          Expand your circle, add new friends,
          With just a click, connections won't end.<br></br>
          Let's grow together, hand in hand,
          Hit 'Generate' and start a friendship brand!
        </p>
        <input
          style={{ ...inputStyles, width: window.innerWidth <= 800 ? '90%' : '40%' }}
          placeholder="Name"
          value={name}
          onChange={(e) => setName(e.target.value)}
        />
  
        <input
          style={{ ...inputStyles, width: window.innerWidth <= 700 ? '90%' : '40%' }}
          placeholder="Phone"
          value={phone}
          onChange={(e) => setPhone(e.target.value)}
        />
        <br />


        <br></br>
        <Button style={{ backgroundColor: '#00AFF0', color: '#FFFFFF', marginBottom: '20px' }} variant="contained" disableElevation onClick={handleOnSubmit}>
          Save Contact :)
        </Button>
        <hr />
      </form>
    </div>
  );
};

export default AddUser;
