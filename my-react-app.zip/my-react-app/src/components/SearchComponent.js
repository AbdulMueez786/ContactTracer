import React, { useState } from 'react';
import User from "./User";

const SearchComponent = ({ data,onDelete }) => {
    const [searchQuery, setSearchQuery] = useState('');

    // Function to handle the input change
    const handleInputChange = (event) => {
        setSearchQuery(event.target.value);
    };

    // Filter the data based on the search query
    const filteredData = data.filter(item =>
        item.name.toLowerCase().includes(searchQuery.toLowerCase())
    );
    // Inline styles for the input field
  const inputStyles = {
    padding: '10px',
    borderRadius: '8px',
    backgroundColor: '#ffffff',
    border: '2px solid #ccc',
    marginTop: '20px',
    fontSize: '16px',
    width: '80%',
    justifycontent: 'center',
    boxSizing: 'border-box',
    outline: 'none',
  };

    return (
        <div>
            <h2>Search Contacts</h2>
            <input
                type="text"
                value={searchQuery}
                style={inputStyles}
                onChange={handleInputChange}
                placeholder="Search Contacts"
            />
            {filteredData.map((user) => (
                <User
                    id={user.id}
                    key={user.id}
                    name={user.name}
                    phone={user.phone}
                    onDelete={onDelete}
                />
            ))}
        </div>
    );
};

export default SearchComponent;
