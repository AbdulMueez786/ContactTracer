import React from 'react'
import './user.css'
import Avatar from '@material-ui/core/Avatar';
import Button from '@material-ui/core/Button';
import DeleteIcon from '@material-ui/icons/Delete';
import PersonIcon from '@material-ui/icons/Person'
const User = ({ id, phone, name, onDelete }) => {

    const handleDelete = () => {
        onDelete(id);
    }

    // Use media query to set the width to 80% when screen width is <= 600px
    const mediaQueryStyles = `@media (max-width: 600px) {
    width: 80%;
  }`;

    const inputStyles = {
        padding: '5px',
        borderRadius: '8px',
        backgroundColor: '#ffffff',
        border: '1px solid #ccc',
        fontSize: '16px',
        marginTop: '20px',
        boxSizing: 'border-box',
        outline: 'none',
        marginLeft:'10%',
        marginRight:'10%',
        display: 'flex', // Add display flex to create a flex container
        alignItems: 'center', // Vertically center the items
        justifyContent: 'center', // Horizontally center the content
    };
    const containerStyles = {
        width: '40%',
        margin: '0 auto', // This centers the component horizontally
        ...mediaQueryStyles, // Apply media query styles
    };
    const infoStyles1 = {
        flex: 1, // This will make the div expand and occupy the available space
        display: 'flex', // Ensure items are displayed horizontally
    };
    const infoStyles2 = {
        flex: 1, // This will make the div expand and occupy the available space
        display: 'flex', // Ensure items are displayed horizontally

    };

    return (
        <div>
            <div style={{ ...inputStyles, width: window.innerWidth <= 700 ? '80%' : '80%' }}>
                <Avatar style={{ marginRight: '20px' }}> {/* Add the Avatar component */}
                    <PersonIcon /> {/* Use the desired icon, e.g., DeleteIcon */}
                </Avatar>

                <div style={infoStyles1}>
                    <span>{name}</span>
                </div>
                <div style={infoStyles2}>
                    <span>{phone}</span>
                </div>

                <span>
                    {<DeleteIcon color='secondary' onClick={handleDelete} />}

                </span>
            </div>
        </div>
    )
}

export default User
