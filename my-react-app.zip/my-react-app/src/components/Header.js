import React from 'react'
import { Navbar,Nav,Container } from 'react-bootstrap';

export const Header = ()=> {
  return (
    <Container>
      <Navbar expand="lg" className="bg-body-tertiary">
        <Container>
          <Navbar.Brand href="#">Navbar</Navbar.Brand>
        </Container>
      </Navbar>
    </Container>
  );
}